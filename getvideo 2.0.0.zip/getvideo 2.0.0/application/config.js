/*
getVideo - v2.0.0
Sameera Damith
damith.sameera1@gmail.com
*/

var config = {

  //Application Title
  title : "GetVideo: Download YouTube Videos Free.",

  //Error Page Title
  errorTitle : "Page not Found (404) - GetVideo",

  //Application URL
  url : "http://example.com",

  //Application Description
  description : "Free online download YouTube videos, audio quickly in 1080p, 720p, MP4, 3GP, and more.",

  //Footer text
  footerText : "getVideo (v2.0.0) &copy; 2020"
};

module.exports = config;
